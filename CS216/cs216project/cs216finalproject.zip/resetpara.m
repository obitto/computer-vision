covariance = oldcovariance;
weight = oldweight;
center = oldcenter;